<!--================Header Menu Area =================-->
<header class="header_area">
    <div class="main_menu">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container box_1620">
                <!-- Brand and toggle get grouped for better mobile display -->
                
                
                <a class="navbar-brand logo_h" href="<?php echo e(route('index')); ?>"
                    style="color: whitesmoke; font-weight: bold"><img class="img-responsive" src="<?php echo e(asset('bootstrap_assets/img/logoReady.png')); ?>" alt="" width="70" height="70"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                    <ul class="nav navbar-nav menu_nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="<?php echo e(route('index')); ?>"><span
                                    class="fa fa-home fa-2x"></span></a></li>
                        

                        <li class="nav-item submenu dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">About</a>
                            <ul class="dropdown-menu">
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('ajssaifpu')); ?>">AJSSAIFPU</a></li>
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('authorship')); ?>">Authorship</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('peer.review')); ?>">Peer
                                        Review</a></li>
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('duplicate.publication')); ?>">Duplicate Publication</a>
                                </li>
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('plagiarism')); ?>">Plagiarism</a></li>

                            </ul>
                        </li>

                        <li class="nav-item submenu dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">Publication</a>
                            <ul class="dropdown-menu">
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('charges')); ?>">Charges</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('steps')); ?>">Steps</a>
                                </li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('ethics')); ?>">Ethics</a>
                                </li>
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('review.process')); ?>">Review Process</a></li>
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('guidelines')); ?>">Guidelines</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('payment.mode')); ?>">Mode
                                        of Payment</a></li>
                                
                            </ul>
                        </li>
                        <li class="nav-item submenu dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">Download</a>
                            <ul class="dropdown-menu">
                                <li class="nav-item"><a class="nav-link" href="#">Copyright Form</a></li>
                                <li class="nav-item"><a class="nav-link" href="#">Paper Template</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('download.more')); ?>">More Documents</a></li>
                            </ul>
                        </li>

                        

                        <li class="nav-item submenu dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">Special Events</a>
                            <ul class="dropdown-menu">
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('callforpaper')); ?>">Call
                                        for Conference</a></li>
                                <li class="nav-item"><a class="nav-link"
                                        href="<?php echo e(route('futureconference')); ?>">Future Conference</a></li>
                            </ul>
                        </li>

                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact.us')); ?>">Contact</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('editors')); ?>">Editorial</a>
                        </li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="nav-item"><a href="<?php echo e(route('submit.paper.form')); ?>"
                                class="tickets_btn">Submit Paper</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</header>
<!--================Header Menu Area =================-->
<!--================ start footer Area  =================-->
<?php echo $__env->make('layout.footerwriteup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--================ End footer Area  =================-->

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('bootstrap_assets/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/stellar.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/lightbox/simpleLightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/isotope/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/isotope/isotope-min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/flipclock/timer.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/counter-up/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/vendors/counter-up/jquery.counterup.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/mail-script.js')); ?>"></script>
<!--gmaps Js-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/gmaps.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap_assets/js/theme.js')); ?>"></script>
</body>

</html>
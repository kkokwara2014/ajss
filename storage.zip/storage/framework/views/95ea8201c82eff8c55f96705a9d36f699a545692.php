<?php if(session('success')): ?>
    <p class="alert alert-success"><?php echo e(session('success')); ?></p>
<?php endif; ?>
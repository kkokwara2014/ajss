<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="<?php echo e(asset('bootstrap_assets/img/ajssaifpu_logo.jpg')); ?>" type="image/png/jpg">
        <title><?php echo e($title); ?></title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/vendors/linericon/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/vendors/owl-carousel/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/vendors/lightbox/simpleLightbox.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/vendors/nice-select/css/nice-select.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/vendors/animate-css/animate.css')); ?>">
        <!-- main css -->
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap_assets/css/responsive.css')); ?>">
    </head>

    <body>

        <!--================Header Menu Area =================-->
        <?php echo $__env->make('layout.headmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--================Header Menu Area =================-->

        <!--================Home Banner Area =================-->
        <section class="banner_area">
            <div class="banner_inner d-flex align-items-center">
                <div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0"
                    data-background=""></div>
                <div class="container">
                    <div class="banner_content text-center">
                        <div class="page_link">
                            <a href="<?php echo e(route('index')); ?>">Home</a>
                            <a href="#">Download</a>
                        </div>
                        <h2>More Documents</h2>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Home Banner Area =================-->


        <!--================Welcome Area =================-->
        <section class="welcome_area pad_btm">
            <div class="container">
                    
                <div class="welcome_inner row" style="margin-top: 50px;">

                    <div class="col-lg-9 col-sm-9">
                        <div class="welcome_text">
                                <h3>Download More Documents</h3>
                                
                           <p style="text-align: justify">You can download more documents from here.</p>

                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-3">
                            <?php echo $__env->make('layout.rightsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                </div>
            </div>
        </section>
        <!--================End Welcome Area =================-->


        <!--================ start footer Area  =================-->
        <?php echo $__env->make('layout.footerwriteup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--================ End footer Area  =================-->

        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="<?php echo e(asset('bootstrap_assets/js/jquery-3.2.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/popper.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/stellar.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/lightbox/simpleLightbox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/isotope/imagesloaded.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/isotope/isotope-min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/flipclock/timer.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/counter-up/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/vendors/counter-up/jquery.counterup.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/mail-script.js')); ?>"></script>
        <!--gmaps Js-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/gmaps.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap_assets/js/theme.js')); ?>"></script>
    </body>

</html>
<footer class="footer-area p_120">
    <div class="container">
        <div class="row">
            <div class="col-lg-3  col-md-3 col-sm-3">
                <div class="single-footer-widget tp_widgets">
                    <h6 class="footer_title">Useful Links</h6>
                    <ul class="list">
                    <li><a href="<?php echo e(route('editors')); ?>">Editorial Board</a></li>
                        <li><a href="<?php echo e(route('submit.paper')); ?>">Submit Paper</a></li>
                        <li><a href="<?php echo e(route('contact.us')); ?>">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3  col-md-3 col-sm-3">
                <div class="single-footer-widget tp_widgets">
                    <h6 class="footer_title">Publication</h6>
                    <ul class="list">
                        <li><a href="<?php echo e(route('charges')); ?>">Charges</a></li>
                        <li><a href="<?php echo e(route('steps')); ?>">Steps</a></li>
                        <li><a href="<?php echo e(route('ethics')); ?>">Ethics</a></li>
                        <li><a href="<?php echo e(route('review.process')); ?>">Review Process</a></li>
                        <li><a href="<?php echo e(route('guidelines')); ?>">Guidelines</a></li>
                        <li><a href="<?php echo e(route('payment.mode')); ?>">Mode of Payment</a></li>
                        
                    </ul>
                </div>
            </div>
            <div class="col-lg-3  col-md-3 col-sm-3">
                <div class="single-footer-widget tp_widgets">
                    <h6 class="footer_title">Special Events</h6>
                    <ul class="list">
                        <li><a href="<?php echo e(route('callforpaper')); ?>">Call for Conference</a></li>
                        <li><a href="<?php echo e(route('futureconference')); ?>">Future Conference</a></li>

                    </ul>
                </div>
            </div>

            <div class="col-lg-3  col-md-3 col-sm-3">
                <div class="single-footer-widget tp_widgets">
                    <h6 class="footer_title">Download</h6>
                    <ul class="list">
                        <li><a href="#">Copyright Form</a></li>
                        <li><a href="#">Paper Template</a></li>
                        <li><a href="<?php echo e(route('download.more')); ?>">More Documents</a></li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="row footer-bottom d-flex justify-content-between align-items-center">
            <p class="col-lg-8 col-md-8 footer-text m-0">

                Copyright &copy; 2017 - <script>
                    document.write(new Date().getFullYear());
                </script> ajssaifpu.org | All rights reserved
                
                <div style="text-align: right">Designed by Done-Right Systems Inc.</div>
        </div>
    </div>
</footer>